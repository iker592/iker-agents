import json
import boto3
import os
import uuid
from typing import Any

client = boto3.client('bedrock-agentcore')

# Runtime ARNs from environment
RUNTIME_ARNS = json.loads(os.environ.get('RUNTIME_ARNS', '{}'))

def handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Proxy requests to Bedrock AgentCore runtimes."""

    # CORS headers
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type,Authorization',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
        'Content-Type': 'application/json'
    }

    # Handle preflight
    if event.get('httpMethod') == 'OPTIONS':
        return {
            'statusCode': 200,
            'headers': headers,
            'body': ''
        }

    try:
        # Support both API Gateway v1 (REST) and v2 (HTTP) payload formats
        path = event.get('rawPath') or event.get('path', '')
        method = event.get('requestContext', {}).get('http', {}).get('method') or event.get('httpMethod', 'GET')
        body = json.loads(event.get('body', '{}')) if event.get('body') else {}

        # Build ID-to-ARN mapping (convert name to lowercase-dash ID)
        def get_agent_id(name):
            return name.lower().replace(' ', '-')

        AGENT_ID_TO_ARN = {get_agent_id(name): arn for name, arn in RUNTIME_ARNS.items()}
        AGENT_ID_TO_NAME = {get_agent_id(name): name for name in RUNTIME_ARNS.keys()}

        # GET /agents - List available agents
        if path == '/agents' and method == 'GET':
            agents = []
            for name, arn in RUNTIME_ARNS.items():
                agents.append({
                    'id': get_agent_id(name),
                    'name': name,
                    'runtime_arn': arn,
                    'status': 'active'
                })

            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'agents': agents})
            }

        # POST /invoke - Invoke an agent
        if path == '/invoke' and method == 'POST':
            agent_id = body.get('agent_id')
            input_text = body.get('input', '')
            # Generate session ID with minimum 33 chars (uuid.hex = 32 chars)
            session_id = body.get('session_id') or f"s-{uuid.uuid4().hex}"

            # Extract authenticated user from JWT claims (set by API Gateway authorizer)
            # Falls back to body.user_id or default for unauthenticated requests
            jwt_claims = event.get('requestContext', {}).get('authorizer', {}).get('jwt', {}).get('claims', {})
            user_id = jwt_claims.get('sub') or jwt_claims.get('email') or body.get('user_id', 'anonymous-user')

            # Log authenticated user for audit
            if jwt_claims:
                print(f"Authenticated request from user: {user_id}")

            if not agent_id or agent_id not in AGENT_ID_TO_ARN:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({
                        'error': f'Invalid agent_id: {agent_id}',
                        'available': list(AGENT_ID_TO_ARN.keys())
                    })
                }

            runtime_arn = AGENT_ID_TO_ARN[agent_id]

            # Build payload for AgentCore
            payload = {
                'input': input_text,
                'user_id': user_id,
                'session_id': session_id,
                'stream': False
            }

            # Invoke AgentCore runtime
            invoke_params = {
                'agentRuntimeArn': runtime_arn,
                'runtimeSessionId': session_id,
                'payload': json.dumps(payload)
            }

            response = client.invoke_agent_runtime(**invoke_params)

            # Parse non-streaming response
            response_body = response['response'].read()
            response_data = json.loads(response_body)

            # Log full response for debugging
            print(f"AgentCore response: {json.dumps(response_data)}")

            # Extract output from response (structure may vary)
            output = response_data.get('output', '')
            if not output and 'text' in response_data:
                output = response_data['text']
            if not output and 'content' in response_data:
                output = response_data['content']
            if not output:
                # If still no output, return the whole response for debugging
                output = json.dumps(response_data)

            result = {
                'output': output,
                'session_id': session_id,
            }

            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps(result)
            }

        # Default 404
        return {
            'statusCode': 404,
            'headers': headers,
            'body': json.dumps({'error': 'Not found'})
        }

    except Exception as e:
        import traceback
        error_details = traceback.format_exc()
        print(f"Error: {error_details}")
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': str(e), 'details': error_details})
        }
